#!/bin/bash

export NDK=/Users/chenlu/Library/Android/sdk/ndk/android-ndk-r20b
export TOOLCHAIN=$NDK/toolchains/llvm/prebuilt/darwin-x86_64
export SYSROOT=$TOOLCHAIN/sysroot

set -e

# 设置架构类型: 64位 (aarch64) 或 32位 (arm)
ARCH_TYPE="32bit"  # 修改此变量以切换架构类型，可选值为 "64bit" 或 "32bit"

if [ "$ARCH_TYPE" == "64bit" ]; then
    ARCH=aarch64
    PLATFORM=aarch64-linux-android
    API=21
elif [ "$ARCH_TYPE" == "32bit" ]; then
    ARCH=arm
    PLATFORM=armv7a-linux-androideabi
    API=16
else
    echo "Unsupported architecture type: $ARCH_TYPE"
    exit 1
fi

PREFIX=$(pwd)/android/$ARCH

# 创建输出目录
mkdir -p $PREFIX

# 配置编译参数
./configure \
    --host=$PLATFORM \
    --disable-shared \
    --enable-static \
    --prefix=$PREFIX \
    CC=$TOOLCHAIN/bin/$PLATFORM$API-clang \
    CXX=$TOOLCHAIN/bin/$PLATFORM$API-clang++ \
    LD=$TOOLCHAIN/bin/$PLATFORM-ld \
    AR=$TOOLCHAIN/bin/$PLATFORM-ar \
    RANLIB=$TOOLCHAIN/bin/$PLATFORM-ranlib \
    STRIP=$TOOLCHAIN/bin/$PLATFORM-strip \
    --with-sysroot=$SYSROOT

# 编译并安装
make clean
make -j$(nproc)
make install
